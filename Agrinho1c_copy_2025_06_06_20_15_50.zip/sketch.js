let jardineiro;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;

let img;
let objeto ;
 
function preload(){
  img = loadImage("machado.png");
}


function setup() {
  createCanvas(600, 400);
  jardineiro = new Jardineiro(width / 2, height - 50);
  objeto = new Machado();
}

function draw() {
  let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208), map(totalArvores, 0, 100, 0, 1));
  background(corFundo);
  mostrarInformacao();
  objeto.exibir();
  
  temperatura += 0.1;
  jardineiro.mostrar();
  jardineiro.atualizar();
  
  plantas.map((arvore) => arvore.mostrar());
}

function mostrarInformacao(){
  textSize(20);
  text("Temperatura: " + temperatura.toFixed(2), 10, 30);
  text("Árvores plantadas: " +totalArvores, 10, 50);
  text("Para movimentar o personagem use as setas do teclado.", 10, 70);
}

//Classe que cria o jardineiro
class Jardineiro{
  constructor(x, y){
    this.x = x;
    this.y = y;
    this.emoji = '👨‍🌾';
    this.velocidade = 3;
  }
  atualizar(){
    if (keyIsDown(LEFT_ARROW)){
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)){
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)){
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)){
      this.y += this.velocidade;
    }
  }
  mostrar(){
    textSize(32);
    text(this.emoji, this.x, this.y);
  }
}

function keyPressed(){
  if( key === ' ' || key ==='p'){
    let arvore = new Arvore(jardineiro.x, jardineiro.y);
      plantas.push(arvore);
      totalArvores++;
      temperatura -= 3;
      if (temperatura < 0) temperatura = 0;
    }
  }


class Arvore{
  constructor(x, y){
    this.x = x;
    this.y = y;
    this.emoji = '🌳';
  }
    mostrar(){
    textSize(32);
    text(this.emoji, this.x, this.y);
  }
}


class Machado{
  constructor(){
    this.x = 300;
    this.y = 200;
  }
  exibir(){
    image(img, this.x, this.y, 300, 300);
  }
}
  
  
  
  
  
  
